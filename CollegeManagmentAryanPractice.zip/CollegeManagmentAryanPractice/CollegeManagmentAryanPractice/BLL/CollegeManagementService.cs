﻿using System;
using System.Collections.Generic;
using CollegeManagmentAryanPractice.DAL;
using CollegeManagmentAryanPractice.MODEL;

namespace CollegeManagmentAryanPractice.BLL
{
    public class CollegeManagementService
    {
        private readonly ICollegeManagementRepository _repository;

        public CollegeManagementService()
        {
            _repository = new CollegeManagementRepository();
        }

        // ================= APPLICANTS =================

        public List<Applicants> GetAllApplicants()
        {
            return _repository.GetAllApplicants();
        }

        public Applicants GetApplicantById(int id)
        {
            return _repository.GetApplicantsById(id);
        }

        public void AddApplicant(Applicants applicant)
        {
            ValidateApplicant(applicant);

            // if exists: check if another applicant already has this email
            foreach (Applicants a in _repository.GetAllApplicants())
            {
                if (a.Email == applicant.Email)
                    throw new Exception("This applicant already exists.");
            }

            _repository.Add(applicant);
        }

        public void EditApplicant(Applicants applicant)
        {
            if (applicant.ApplicantId <= 0) throw new Exception("Select an applicant first.");
            ValidateApplicant(applicant);
            _repository.Update(applicant);
        }

        public void DeleteApplicant(int id)
        {
            if (id <= 0) throw new Exception("Select an applicant first.");
            _repository.DeleteApplicantsById(id);
        }

        private void ValidateApplicant(Applicants applicant)
        {
            if (applicant == null) throw new Exception("Applicant is empty.");
            if (applicant.FirstName == "") throw new Exception("First name is required.");
            if (applicant.LastName == "") throw new Exception("Last name is required.");
            if (applicant.Email == "") throw new Exception("Email is required.");
        }

        // ================= WEBINARS =================

        public List<Webinars> GetAllWebinars()
        {
            return _repository.GetAllWebinars();
        }

        public Webinars GetWebinarByCode(string code)
        {
            return _repository.GetWebinarsByCode(code);
        }

        public void AddWebinar(Webinars webinar)
        {
            ValidateWebinar(webinar);

            // if exists: GetWebinarsByCode returns null when the code is NOT found
            if (_repository.GetWebinarsByCode(webinar.WebinarCode) != null)
                throw new Exception("This webinar code already exists.");

            _repository.Add(webinar);
        }

        // Edit: change the webinar information
        public void EditWebinar(Webinars webinar)
        {
            ValidateWebinar(webinar);
            _repository.Update(webinar);
        }

        // Update: change only the starting and ending dates
        public void UpdateWebinarDates(string code, DateTime startingDate, DateTime endingDate)
        {
            Webinars webinar = _repository.GetWebinarsByCode(code);
            if (webinar == null) throw new Exception("Select a webinar first.");

            webinar.StartingDate = startingDate;
            webinar.EndingDate = endingDate;

            ValidateWebinar(webinar);
            _repository.Update(webinar);
        }

        public void DeleteWebinar(string code)
        {
            if (code == "") throw new Exception("Select a webinar first.");
            _repository.DeleteWebinarsByCode(code);
        }

        private void ValidateWebinar(Webinars webinar)
        {
            if (webinar == null) throw new Exception("Webinar is empty.");
            if (webinar.WebinarCode == "") throw new Exception("Webinar code is required.");
            if (webinar.WebinarName == "") throw new Exception("Webinar name is required.");
            if (webinar.TotalHour <= 0) throw new Exception("Total hours must be greater than 0.");
            if (webinar.EndingDate < webinar.StartingDate)
                throw new Exception("Ending date can't be before the starting date.");
        }

        // ================= REGISTRATION =================
        public List<ApplicantsWebinars> GetAllRegistrations()
        {
            return _repository.GetAllApplicantsWebinars();
        }
        public void Register(ApplicantsWebinars registration)
        {
            if (registration == null) throw new Exception("Registration is empty.");

            // both must exist before registering
            if (_repository.GetApplicantsById(registration.ApplicantId) == null)
                throw new Exception("Applicant not found.");
            if (_repository.GetWebinarsByCode(registration.WebinarCode) == null)
                throw new Exception("Webinar not found.");

            registration.RegistrationDate = DateTime.Now;
            _repository.Add(registration);
        }
    }


}