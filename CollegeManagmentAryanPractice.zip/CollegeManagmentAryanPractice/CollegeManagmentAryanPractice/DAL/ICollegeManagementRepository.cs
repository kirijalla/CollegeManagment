﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CollegeManagmentAryanPractice.MODEL;
namespace CollegeManagmentAryanPractice.DAL
{
    public interface ICollegeManagementRepository
    {
        List<Applicants> GetAllApplicants();//done

        List<Webinars> GetAllWebinars();//done
        List<ApplicantsWebinars> GetAllApplicantsWebinars();//done

        Applicants GetApplicantsById(int id);
        Webinars GetWebinarsByCode(string webinarCode);
        void Add(Applicants applicants);//done
        void Add(Webinars webinars);//done

        void Add(ApplicantsWebinars addedApplicantsWebinars);
        void Update(Applicants updatedApplicants);

        void Update(Webinars updatedWebinars);

        void DeleteApplicantsById(int id);
        void DeleteWebinarsByCode(string webinarsCode);



    }
}
