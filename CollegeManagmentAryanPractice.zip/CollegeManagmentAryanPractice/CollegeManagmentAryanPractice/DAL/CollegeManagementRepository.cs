﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using CollegeManagmentAryanPractice.MODEL;

namespace CollegeManagmentAryanPractice.DAL
{
    public class CollegeManagementRepository : ICollegeManagementRepository
    {
        private readonly string connectionString =
            ConfigurationManager.ConnectionStrings["TechnoCollegeManagmentAryanPractice"].ConnectionString;

        // =====================================================
        // MAPPING HELPERS: turn one DataRow into one object
        // =====================================================

        private Applicants MapToApplicant(DataRow row)
        {
            Applicants applicant = new Applicants();
            applicant.ApplicantId = Convert.ToInt32(row["ApplicantId"]);
            applicant.FirstName = row["FirstName"].ToString();
            applicant.LastName = row["LastName"].ToString();
            applicant.Email = row["Email"].ToString();
            return applicant;
        }

        private Webinars MapToWebinar(DataRow row)
        {
            Webinars webinar = new Webinars();
            webinar.WebinarCode = row["WebinarCode"].ToString();
            webinar.WebinarName = row["WebinarName"].ToString();
            webinar.TotalHour = Convert.ToInt32(row["TotalHour"]);
            webinar.StartingDate = Convert.ToDateTime(row["StartingDate"]);
            webinar.EndingDate = Convert.ToDateTime(row["EndingDate"]);
            return webinar;
        }

        private ApplicantsWebinars MapToRegistration(DataRow row)
        {
            ApplicantsWebinars registration = new ApplicantsWebinars();
            registration.ApplicantId = Convert.ToInt32(row["ApplicantId"]);
            registration.WebinarCode = row["WebinarCode"].ToString();
            registration.RegistrationDate = Convert.ToDateTime(row["RegistrationDate"]);
            return registration;
        }

        // =====================================================
        // GET ALL
        // =====================================================

        public List<Applicants> GetAllApplicants()
        {
            SqlConnection conn = new SqlConnection(connectionString);
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM dbo.Applicants", conn);

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            List<Applicants> items = new List<Applicants>();
            foreach (DataRow row in dt.Rows)
            {
                items.Add(MapToApplicant(row));
            }
            return items;
        }

        public List<Webinars> GetAllWebinars()
        {
            SqlConnection conn = new SqlConnection(connectionString);
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM dbo.Webinars", conn);

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            List<Webinars> items = new List<Webinars>();
            foreach (DataRow row in dt.Rows)
            {
                items.Add(MapToWebinar(row));
            }
            return items;
        }

        public List<ApplicantsWebinars> GetAllApplicantsWebinars()
        {
            SqlConnection conn = new SqlConnection(connectionString);
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM dbo.ApplicantsWebinars", conn);

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            List<ApplicantsWebinars> items = new List<ApplicantsWebinars>();
            foreach (DataRow row in dt.Rows)
            {
                items.Add(MapToRegistration(row));
            }
            return items;
        }

        // =====================================================
        // GET ONE (returns null if not found)
        // =====================================================

        public Applicants GetApplicantsById(int id)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            SqlDataAdapter adapter = new SqlDataAdapter(
                "SELECT * FROM dbo.Applicants WHERE ApplicantId = @id", conn);
            adapter.SelectCommand.Parameters.Add("@id", SqlDbType.Int).Value = id;

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            if (dt.Rows.Count == 0) return null;
            return MapToApplicant(dt.Rows[0]);
        }

        public Webinars GetWebinarsByCode(string webinarCode)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            SqlDataAdapter adapter = new SqlDataAdapter(
                "SELECT * FROM dbo.Webinars WHERE WebinarCode = @code", conn);
            adapter.SelectCommand.Parameters.Add("@code", SqlDbType.NVarChar, 50).Value = webinarCode;

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            if (dt.Rows.Count == 0) return null;
            return MapToWebinar(dt.Rows[0]);
        }

        // =====================================================
        // ADD (new row → RowState Added → InsertCommand)
        // =====================================================

        public void Add(Applicants applicants)
        {
            if (applicants == null) throw new ArgumentNullException(nameof(applicants));

            SqlConnection conn = new SqlConnection(connectionString);
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM dbo.Applicants", conn);

            // ApplicantId is IDENTITY, so it is not in the INSERT
            adapter.InsertCommand = new SqlCommand(
                @"INSERT INTO dbo.Applicants (FirstName, LastName, Email)
                  VALUES (@FirstName, @LastName, @Email)", conn);
            adapter.InsertCommand.Parameters.Add("@FirstName", SqlDbType.NVarChar, 50, "FirstName");
            adapter.InsertCommand.Parameters.Add("@LastName", SqlDbType.NVarChar, 50, "LastName");
            adapter.InsertCommand.Parameters.Add("@Email", SqlDbType.NVarChar, 50, "Email");

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            DataRow row = dt.NewRow();
            row["FirstName"] = applicants.FirstName;
            row["LastName"] = applicants.LastName;
            row["Email"] = applicants.Email;
            dt.Rows.Add(row);

            adapter.Update(dt);
        }

        public void Add(Webinars webinars)
        {
            if (webinars == null) throw new ArgumentNullException(nameof(webinars));

            SqlConnection conn = new SqlConnection(connectionString);
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM dbo.Webinars", conn);

            // WebinarCode is typed by the user, so it IS in the INSERT
            adapter.InsertCommand = new SqlCommand(
                @"INSERT INTO dbo.Webinars (WebinarCode, WebinarName, TotalHour, StartingDate, EndingDate)
                  VALUES (@code, @name, @totalHour, @stDate, @endDate)", conn);
            adapter.InsertCommand.Parameters.Add("@code", SqlDbType.NVarChar, 50, "WebinarCode");
            adapter.InsertCommand.Parameters.Add("@name", SqlDbType.NVarChar, 50, "WebinarName");
            adapter.InsertCommand.Parameters.Add("@totalHour", SqlDbType.Int, 0, "TotalHour");
            adapter.InsertCommand.Parameters.Add("@stDate", SqlDbType.DateTime, 0, "StartingDate");
            adapter.InsertCommand.Parameters.Add("@endDate", SqlDbType.DateTime, 0, "EndingDate");

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            DataRow row = dt.NewRow();
            row["WebinarCode"] = webinars.WebinarCode;
            row["WebinarName"] = webinars.WebinarName;
            row["TotalHour"] = webinars.TotalHour;
            row["StartingDate"] = webinars.StartingDate;
            row["EndingDate"] = webinars.EndingDate;
            dt.Rows.Add(row);

            adapter.Update(dt);
        }

        public void Add(ApplicantsWebinars addedApplicantsWebinars)
        {
            if (addedApplicantsWebinars == null) throw new ArgumentNullException(nameof(addedApplicantsWebinars));

            SqlConnection conn = new SqlConnection(connectionString);
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM dbo.ApplicantsWebinars", conn);

            // no IDENTITY in this table, so all 3 columns are inserted
            adapter.InsertCommand = new SqlCommand(
                @"INSERT INTO dbo.ApplicantsWebinars (ApplicantId, WebinarCode, RegistrationDate)
                  VALUES (@applicantId, @code, @regDate)", conn);
            adapter.InsertCommand.Parameters.Add("@applicantId", SqlDbType.Int, 0, "ApplicantId");
            adapter.InsertCommand.Parameters.Add("@code", SqlDbType.NVarChar, 10, "WebinarCode");
            adapter.InsertCommand.Parameters.Add("@regDate", SqlDbType.DateTime, 0, "RegistrationDate");

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            DataRow row = dt.NewRow();
            row["ApplicantId"] = addedApplicantsWebinars.ApplicantId;
            row["WebinarCode"] = addedApplicantsWebinars.WebinarCode;
            row["RegistrationDate"] = addedApplicantsWebinars.RegistrationDate;
            dt.Rows.Add(row);

            adapter.Update(dt);
        }

        // =====================================================
        // UPDATE (changed row → RowState Modified → UpdateCommand)
        // =====================================================

        public void Update(Applicants updatedApplicants)
        {
            if (updatedApplicants == null) throw new ArgumentNullException(nameof(updatedApplicants));

            SqlConnection conn = new SqlConnection(connectionString);

            // 1- copy only the row we want to change
            SqlDataAdapter adapter = new SqlDataAdapter(
                "SELECT * FROM dbo.Applicants WHERE ApplicantId = @id", conn);
            adapter.SelectCommand.Parameters.Add("@id", SqlDbType.Int).Value = updatedApplicants.ApplicantId;

            // 2- tell the adapter HOW to update
            adapter.UpdateCommand = new SqlCommand(
                @"UPDATE dbo.Applicants
                  SET FirstName = @FirstName, LastName = @LastName, Email = @Email
                  WHERE ApplicantId = @ApplicantId", conn);
            adapter.UpdateCommand.Parameters.Add("@FirstName", SqlDbType.NVarChar, 50, "FirstName");
            adapter.UpdateCommand.Parameters.Add("@LastName", SqlDbType.NVarChar, 50, "LastName");
            adapter.UpdateCommand.Parameters.Add("@Email", SqlDbType.NVarChar, 50, "Email");
            SqlParameter idParam = adapter.UpdateCommand.Parameters.Add("@ApplicantId", SqlDbType.Int, 0, "ApplicantId");
            idParam.SourceVersion = DataRowVersion.Original;   // find the row by its ORIGINAL id

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            if (dt.Rows.Count == 0)
                throw new Exception($"Applicant with Id {updatedApplicants.ApplicantId} was not found.");

            // 3- change the row in memory (RowState becomes Modified)
            DataRow row = dt.Rows[0];
            row["FirstName"] = updatedApplicants.FirstName;
            row["LastName"] = updatedApplicants.LastName;
            row["Email"] = updatedApplicants.Email;

            // 4- send the change to the database
            adapter.Update(dt);
        }

        public void Update(Webinars updatedWebinars)
        {
            if (updatedWebinars == null) throw new ArgumentNullException(nameof(updatedWebinars));

            SqlConnection conn = new SqlConnection(connectionString);

            SqlDataAdapter adapter = new SqlDataAdapter(
                "SELECT * FROM dbo.Webinars WHERE WebinarCode = @code", conn);
            adapter.SelectCommand.Parameters.Add("@code", SqlDbType.NVarChar, 50).Value = updatedWebinars.WebinarCode;

            // the code is the primary key, so it identifies the row and is not changed
            adapter.UpdateCommand = new SqlCommand(
                @"UPDATE dbo.Webinars
                  SET WebinarName = @name, TotalHour = @totalHour,
                      StartingDate = @stDate, EndingDate = @endDate
                  WHERE WebinarCode = @code", conn);
            adapter.UpdateCommand.Parameters.Add("@name", SqlDbType.NVarChar, 50, "WebinarName");
            adapter.UpdateCommand.Parameters.Add("@totalHour", SqlDbType.Int, 0, "TotalHour");
            adapter.UpdateCommand.Parameters.Add("@stDate", SqlDbType.DateTime, 0, "StartingDate");
            adapter.UpdateCommand.Parameters.Add("@endDate", SqlDbType.DateTime, 0, "EndingDate");
            SqlParameter codeParam = adapter.UpdateCommand.Parameters.Add("@code", SqlDbType.NVarChar, 50, "WebinarCode");
            codeParam.SourceVersion = DataRowVersion.Original;

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            if (dt.Rows.Count == 0)
                throw new Exception($"Webinar with code {updatedWebinars.WebinarCode} was not found.");

            DataRow row = dt.Rows[0];
            row["WebinarName"] = updatedWebinars.WebinarName;
            row["TotalHour"] = updatedWebinars.TotalHour;
            row["StartingDate"] = updatedWebinars.StartingDate;
            row["EndingDate"] = updatedWebinars.EndingDate;

            adapter.Update(dt);
        }

        // =====================================================
        // DELETE (row.Delete() → RowState Deleted → DeleteCommand)
        // =====================================================

        public void DeleteApplicantsById(int id)
        {
            SqlConnection conn = new SqlConnection(connectionString);

            SqlDataAdapter adapter = new SqlDataAdapter(
                "SELECT * FROM dbo.Applicants WHERE ApplicantId = @id", conn);
            adapter.SelectCommand.Parameters.Add("@id", SqlDbType.Int).Value = id;

            adapter.DeleteCommand = new SqlCommand(
                "DELETE FROM dbo.Applicants WHERE ApplicantId = @ApplicantId", conn);
            adapter.DeleteCommand.Parameters.Add("@ApplicantId", SqlDbType.Int, 0, "ApplicantId");

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            if (dt.Rows.Count == 0)
                throw new Exception($"Applicant with Id {id} was not found.");

            dt.Rows[0].Delete();   // marked as Deleted in memory
            adapter.Update(dt);    // runs the DeleteCommand
        }

        public void DeleteWebinarsByCode(string webinarsCode)
        {
            SqlConnection conn = new SqlConnection(connectionString);

            SqlDataAdapter adapter = new SqlDataAdapter(
                "SELECT * FROM dbo.Webinars WHERE WebinarCode = @code", conn);
            adapter.SelectCommand.Parameters.Add("@code", SqlDbType.NVarChar, 50).Value = webinarsCode;

            adapter.DeleteCommand = new SqlCommand(
                "DELETE FROM dbo.Webinars WHERE WebinarCode = @WebinarCode", conn);
            adapter.DeleteCommand.Parameters.Add("@WebinarCode", SqlDbType.NVarChar, 50, "WebinarCode");

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            if (dt.Rows.Count == 0)
                throw new Exception($"Webinar with code {webinarsCode} was not found.");

            dt.Rows[0].Delete();
            adapter.Update(dt);
        }
    }
}