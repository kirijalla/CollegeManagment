﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollegeManagmentAryanPractice.MODEL
{
    public class ApplicantsWebinars
    {
        public int ApplicantId { get; set; }
        public string WebinarCode { get; set; }
        public DateTime RegistrationDate { get; set; }
        
    }
}
