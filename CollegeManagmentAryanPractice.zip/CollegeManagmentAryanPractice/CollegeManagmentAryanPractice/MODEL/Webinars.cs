﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollegeManagmentAryanPractice.MODEL
{
    public class Webinars
    {
        public string WebinarCode { get; set; }
        public string WebinarName { get; set; }
        public int TotalHour { get; set; }
        public DateTime StartingDate { get; set; }
        public DateTime EndingDate { get; set; }


    }
}
