﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollegeManagmentAryanPractice.MODEL
{
    public class Applicants
    {

        public int ApplicantId { get; set; }
        public string FirstName { get; set; }
        public string LastName  { get; set; }
        public string Email     { get; set; }

        // empty constructor: lets you write new Applicants() and set properties one by one
        //public Applicants()
        //{
        //}

        // constructor with parameters: create a full applicant in one line
        //public Applicants(int applicantId, string firstName, string lastName, string email)
        //{
        //    ApplicantId = applicantId;
        //    FirstName = firstName;
        //    LastName = lastName;
        //    Email = email;
        //}

    }
}
